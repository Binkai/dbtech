package de.htwberlin.utils;

public interface DbCred {
	  final String driverClass = "oracle.jdbc.driver.OracleDriver";
	  final String url = "jdbc:oracle:thin:@oradbs02.f4.htw-berlin.de:1521:orcl";
	  final String user = "u558133";
	  final String password = "p558133";
	  final String schema = "u558133";
}
