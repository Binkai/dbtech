package de.htwberlin.mauterhebung;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.BuchungDaoImpl;
import dao.FahrzeugDaoImpl;
import dao.FahrzeuggeratDaoImpl;
import dao.MautabschnittDaoImpl;
import dao.MautkategorieDaoImpl;
import de.htwberlin.exceptions.AlreadyCruisedException;
import de.htwberlin.exceptions.DataException;
import de.htwberlin.exceptions.InvalidVehicleDataException;
import de.htwberlin.exceptions.UnkownVehicleException;
import object.Buchung;
import object.Fahrzeug;
import object.Fahrzeuggerat;
import object.Mautabschnitt;
import object.Mautkategorie;

/**
 * Die Klasse realisiert den AusleiheService.
 * 
 * @author Patrick Dohmeier
 */
public class MauterServiceImpl implements IMauterhebung {

	private static final Logger L = LoggerFactory.getLogger(MauterServiceImpl.class);
	private Connection connection;

	@Override
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	private Connection getConnection() {
		if (connection == null) {
			throw new DataException("Connection not set");
		}
		return connection;
	}

	@Override
	public float berechneMaut(int mautAbschnitt, int achszahl, String kennzeichen)
			throws UnkownVehicleException, InvalidVehicleDataException, AlreadyCruisedException {
		BuchungDaoImpl bdao = new BuchungDaoImpl();
		bdao.setConnection(getConnection());
		FahrzeugDaoImpl fdao = new FahrzeugDaoImpl();
		fdao.setConnection(getConnection());
		FahrzeuggeratDaoImpl fzgdao = new FahrzeuggeratDaoImpl();
		fzgdao.setConnection(getConnection());
		MautkategorieDaoImpl mkdao = new MautkategorieDaoImpl();
		mkdao.setConnection(getConnection());
		float maut = 0;
		List<Buchung> buchunglist = bdao.getBuchungbyKennzeichenAndlala(kennzeichen, mautAbschnitt);
		Fahrzeug fahrzeug = fdao.getFahrzeugbyKennzeichen(kennzeichen);
		if(buchunglist.get(0) == null) {
			//Automatic Verfahren
			if (fahrzeug == null) {
				throw new UnkownVehicleException();
			} 
			Fahrzeuggerat fahrgerat = fzgdao.getFahrzeuggeratbyKennzeichenAndFZID(fahrzeug.getFzg_id());
			if (fahrgerat == null || fahrzeug.getAbmeldedatum() != null || !(fahrgerat.getStatus().equals("active"))) {
				throw new UnkownVehicleException();
			}
			if(fahrzeug.getAchsen() != achszahl){
				throw new InvalidVehicleDataException();
			}
			//Maut berechnen
			MautabschnittDaoImpl abdao = new MautabschnittDaoImpl();
			abdao.setConnection(getConnection());
			Mautabschnitt mabsch = abdao.getMautabschnittById(mautAbschnitt);
			// TO DO MAUTSATZ ABHOLEN MITHILFE SSKL UND ACHSZAHL!
		}
		if(buchunglist.get(0) != null){
			// Manual Verfahren
			Mautkategorie mamk = mkdao.getMautkategorieByID(buchunglist.get(0).getKategorie_ID());
			String Achszahl = mamk.getAchszahl();
			
			if (Achszahl.contains(">=")) {
				if(!(achszahl >= Character.getNumericValue(Achszahl.charAt(Achszahl.length()-1)))){
					throw new InvalidVehicleDataException();
				}
			} else {
				if(!(Character.getNumericValue(Achszahl.charAt(Achszahl.length()-1)) == achszahl)){
					throw new InvalidVehicleDataException();
				}
			
			}
			//Streckenstatus pr�fen
			boolean eineTrue = false;
			Buchung buchung = new Buchung();
			for (Buchung b : buchunglist) {
					eineTrue = bdao.istBuchungOffen(b);
					if (eineTrue) {
						buchung = b;
						break;
					}
				}
			if (!eineTrue) {
				throw new AlreadyCruisedException(); 
			}
			bdao.updateBuchung(buchung);
			//Update der Buchung
			
		}
		
//		if(!isVehicleRegistered(kennzeichen)){
//			throw new UnkownVehicleException();
//		}
//		if(!isVehicleDataRight(achszahl,kennzeichen, mautAbschnitt)){
//			throw new InvalidVehicleDataException();
//		}
//		if(isVehicleInManual(kennzeichen)){
//			//Manual Ablauf
//			if(!isRouteAlreadyCruised(kennzeichen,mautAbschnitt)) {
//				throw new AlreadyCruisedException();
//			}
//			updateCategory(kennzeichen);
//			
//		}
//		if(isVehicleInAutomatic(kennzeichen)){
//			// Automatic Ablauf
//			int laengeinkm = getMautlaenge(mautAbschnitt)/1000;
//			int mautsatz = getMautsatz(achszahl, kennzeichen)/100;
//			maut = laengeinkm*mautsatz;
//			
//		}
//		
		
		return maut;
	}


	private int getMautsatz(int achszahl, String kennzeichen) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		int mautsatz = 0;
		String query = "SELECT M.MAUTSATZ_JE_KM FROM MAUTKATEGORIE M INNER JOIN SCHADSTOFFKLASSE S ON S.SSKL_ID = M.SSKL_ID INNER JOIN FAHRZEUG F ON F.SSKL_ID = S.SSKL_ID WHERE F.KENNZEICHEN = ? AND m.ACHSZAHL LIKE '%= ?'";
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setString(1, kennzeichen);
			preparedState.setInt(2, achszahl);
			result = preparedState.executeQuery();
			if(result.next()){
				mautsatz = result.getInt(0);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return mautsatz;
	}

	/**
	 * prueft, ob Fahrzeug vorhanden ist  
	 * @author KingKoolKai
	 * @param kennzeichen Das Kennzeichen des Fahrzeugs das gepr�ft wird.
	 * @return true oder false 
	 */
	
	public boolean isVehicleRegistered(String kennzeichen){

		// Resultset.count() anwenden um testen ob positiv oder negativ ist, Ergebnis vorhanden oder nicht
		PreparedStatement preparedState = null;
		ResultSet result = null;
		boolean check = false;
		String query = "SELECT SUM(Anzahl) AS ANZAHL_FZ	FROM(SELECT count(F.FZ_ID) as Anzahl FROM FAHRZEUG F JOIN FAHRZEUGGERAT FZG ON F.FZ_ID = FZG.FZ_ID WHERE F.KENNZEICHEN = ?  AND F.ABMELDEDATUM IS NULL AND FZG.STATUS = 'active' union SELECT count(KENNZEICHEN) AS Anzahl FROM BUCHUNG WHERE b_ID = 1 and Kennzeichen = ?)";
		
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setString(1, kennzeichen);
			preparedState.setString(2, kennzeichen);
			result = preparedState.executeQuery();
			if(result.next()){
			
			return result.getInt("ANZAHL_FZ")>0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}
	public boolean isVehicleDataRight(int Achsen, String Kennzeichen, int abschnitt) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		boolean check = false;
		String queryAM = "SELECT COUNT(ACHSEN) AS Anzahl FROM FAHRZEUG WHERE KENNZEICHEN = ? AND ACHSEN = ?";
		String queryMA = "SELECT M.ACHSZAHL FROM BUCHUNG INNER JOIN MAUTKATEGORIE M ON M.KATEGORIE_ID = BUCHUNG.KATEGORIE_ID WHERE BUCHUNG.KENNZEICHEN = ? AND BUCHUNG.ABSCHNITTS_ID = ? AND BUCHUNG.BEFAHRUNGSDATUM IS NULL";
		
		try {
			preparedState = getConnection().prepareStatement(queryAM);
			preparedState.setString(1, Kennzeichen);
			preparedState.setInt(2, Achsen);
			result = preparedState.executeQuery();
			if(result.next()){
				if( result.getInt("Anzahl") == 0) {
					//Wenn Automatische Verfahren Pr�fung negativ ist, Manuelle Pr�fung durchf�hren (Achszahl von der Buchungs mautkategorie mit Achszahl pr�fen)
					preparedState = getConnection().prepareStatement(queryMA);
					preparedState.setString(1, Kennzeichen);
					preparedState.setInt(2, abschnitt);
					result = preparedState.executeQuery();
					if(result.next()){
						String achszahlDB = result.getString(1);
						int achszahlDBzahl = Integer.parseInt(achszahlDB.substring(achszahlDB.length()-1));
						if(achszahlDB.contains(">=")) {
							return Achsen >= achszahlDBzahl;
						}
						if(achszahlDB.contains("=")) {
							System.out.println("hier1");
							return Achsen == achszahlDBzahl;
						}
						
					}
					
			} else {
				return result.getInt("Anzahl") > 0;
			}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("Hier");

		return check;
	}
	public boolean isVehicleInManual(String Kennzeichen){
		PreparedStatement preparedState = null;
		ResultSet result = null;
		boolean check = false;
		String query = "SELECT COUNT(BS.STATUS) AS Anzahl FROM BUCHUNGSTATUS BS INNER JOIN BUCHUNG B ON B.B_ID = BS.B_ID WHERE B.KENNZEICHEN = ? AND BS.STATUS='offen'";
		
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setString(1, Kennzeichen);
			result = preparedState.executeQuery();
			if(result.next()){
			return result.getInt("Anzahl")>0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}
	private boolean isVehicleInAutomatic(String Kennzeichen) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		boolean check = false;
		String query = "SELECT COUNT(FG.STATUS) AS Anzahl FROM FAHRZEUGGERAT FG INNER JOIN FAHRZEUG F ON F.FZ_ID = FG.FZ_ID WHERE F.KENNZEICHEN= ? AND FG.STATUS = 'active'";
		
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setString(1, Kennzeichen);
			result = preparedState.executeQuery();
			if(result.next()){
			return result.getInt("Anzahl")>0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}
	private boolean isRouteAlreadyCruised(String Kennzeichen, int Mautabschnitt) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		boolean check = false;
		String query = "SELECT COUNT(BS.STATUS) AS Anzahl FROM BUCHUNGSTATUS BS INNER JOIN BUCHUNG B ON B.B_ID = BS.B_ID WHERE B.KENNZEICHEN = ? AND B.ABSCHNITTS_ID = ? AND BS.STATUS = 'offen'";
		
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setString(1, Kennzeichen);
			preparedState.setInt(2, Mautabschnitt);
			result = preparedState.executeQuery();
			if(result.next()){
			return result.getInt("Anzahl")>0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}
//	private boolean checkTollCategory(int Mautabschnitt, int Achszahl) {
//		
//	}
	private void updateCategory(String Kennzeichen) {
		
		// TO DO FINISH UPDATE WITH INNER JOIN
		PreparedStatement preparedState = null;
		boolean check = false;
				//UPDATE BUCHUNGSTATUS SET BUCHUNGSTATUS.STATUS = 'abgeschlossen' WHERE BUCHUNGSTATUS.STATUS = 'offen' AND EXISTS(SELECT * FROM BUCHUNG WHERE BEFAHRUNGSDATUM IS NULL AND KENNZEICHEN = ?) KRASSE QUERY
		String queryUPSTATUS = "UPDATE BUCHUNG SET BUCHUNG.B_ID = 3 WHERE BUCHUNG.KENNZEICHEN= ? AND BUCHUNG.BEFAHRUNGSDATUM IS NULL AND BUCHUNG.B_ID = 1";
		String queryUPBEFAHRUNGSDATUM = "UPDATE BUCHUNG  SET BUCHUNG.BEFAHRUNGSDATUM = CURRENT_DATE WHERE BUCHUNG.kennzeichen = ? AND BUCHUNG.BEFAHRUNGSDATUM IS NULL";
		try {
			preparedState = getConnection().prepareStatement(queryUPSTATUS);
			preparedState.setString(1, Kennzeichen);
			int anzahl = preparedState.executeUpdate();
			if(anzahl > 0) {
				preparedState = getConnection().prepareStatement(queryUPBEFAHRUNGSDATUM);
				preparedState.setString(1, Kennzeichen);
				anzahl = preparedState.executeUpdate();
			}


		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private int getMautlaenge(int mautabschnitt){
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT LAENGE FROM MAUTABSCHNITT WHERE ABSCHNITTS_ID = ?";
		int laenge = 0;
		try {
			preparedState = getConnection().prepareStatement(query);
			preparedState.setInt(1, mautabschnitt);
			result = preparedState.executeQuery();
			if(result.next()){
				laenge = result.getInt(0);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return laenge;
	}
}
