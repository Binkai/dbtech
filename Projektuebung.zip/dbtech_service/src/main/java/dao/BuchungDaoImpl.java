package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import object.Buchung;
public class BuchungDaoImpl implements BuchungDao {

	private Connection connection;
	public void setConnection(Connection connection){
		this.connection = connection;
	}
	@Override
	public List<Buchung> getBuchungbyKennzeichenAndlala(String kennzeichen, int Abschnitts_id) {
		// TODO Auto-generated method stub
		PreparedStatement preparedState = null;
		ResultSet result = null;
		List<Buchung> buchungen = new LinkedList<Buchung>();
		String query = "SELECT * FROM BUCHUNG WHERE KENNZEICHEN = ? AND ABSCHNITTS_ID = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setString(1, kennzeichen);
			preparedState.setInt(2, Abschnitts_id);
			result = preparedState.executeQuery();
			while(result.next()){

				Buchung buch = new Buchung();
				buch.setBefahrungsdatum(result.getDate("Befahrungsdatum"));
				buch.setKennzeichen(kennzeichen);
				buch.setAbschnitts_ID(Abschnitts_id);
				buch.setB_ID(result.getInt("B_ID"));
				buch.setBUCHUNG_ID(result.getInt("BUCHUNG_ID"));
				buch.setKategorie_ID(result.getInt("Kategorie_Id"));
				buchungen.add(buch);
				return buchungen;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean updateBuchung(Buchung buchung) {
		PreparedStatement preparedState = null;
		boolean check = false;
		int anzahl = 0;
				//UPDATE BUCHUNGSTATUS SET BUCHUNGSTATUS.STATUS = 'abgeschlossen' WHERE BUCHUNGSTATUS.STATUS = 'offen' AND EXISTS(SELECT * FROM BUCHUNG WHERE BEFAHRUNGSDATUM IS NULL AND KENNZEICHEN = ?) KRASSE QUERY
		String query = "UPDATE BUCHUNG SET BUCHUNG.B_ID = 3, BUCHUNG.BEFAHRUNGSDATUM = CURRENT_DATE WHERE BUCHUNG_ID = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setInt(1, buchung.getBUCHUNG_ID());
			anzahl = preparedState.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	if(anzahl != 0) {
		check = true;
	}
	return check;
	}
	@Override
	public boolean istBuchungOffen(Buchung buchung) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT COUNT(BUCHUNGSTATUS.STATUS) AS Anzahl FROM BUCHUNG INNER JOIN BUCHUNGSTATUS ON BUCHUNGSTATUS.B_ID = BUCHUNG.B_ID WHERE BUCHUNG_ID = ? AND BUCHUNGSTATUS.STATUS = 'offen'";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setInt(1, buchung.getBUCHUNG_ID());
			result = preparedState.executeQuery();
			if(result.next()){
				return result.getInt("Anzahl")>0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
