package dao;

import object.Mautabschnitt;

public interface MautabschnittDao {

	public Mautabschnitt getMautabschnittById(int abschnitts_id);
	
}
