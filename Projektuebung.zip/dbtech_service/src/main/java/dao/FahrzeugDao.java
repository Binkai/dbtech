package dao;

import object.Fahrzeug;

public interface FahrzeugDao {
	public Fahrzeug getFahrzeugbyKennzeichen(String Kennzeichen);
}
