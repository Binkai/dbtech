package dao;

import java.util.List;

import object.Buchung;

public interface BuchungDao {

	public List<Buchung> getBuchungbyKennzeichenAndlala(String kennzeichen, int Abschnitts_id);
	public boolean updateBuchung(Buchung buchung);
	public boolean istBuchungOffen(Buchung buchung);
}
