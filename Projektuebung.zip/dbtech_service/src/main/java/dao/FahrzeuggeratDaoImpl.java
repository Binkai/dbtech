package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import object.Fahrzeuggerat;

public class FahrzeuggeratDaoImpl implements FahrzeuggeratDao{
	private Connection connection;
	public void setConnection(Connection connection){
		this.connection = connection;
	}
	public Fahrzeuggerat getFahrzeuggeratbyKennzeichenAndFZID(long FZ_ID) {
		// TODO Auto-generated method stub
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT * FROM FAHRZEUGGERAT WHERE FZ_ID = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setLong(1, FZ_ID);
			result = preparedState.executeQuery();
			if(result.next()){
				System.out.println("test");
				Fahrzeuggerat fahrgerat = new Fahrzeuggerat();
				fahrgerat.setFZGerat_ID(result.getInt("FZG_ID"));
				fahrgerat.setStatus(result.getString("STATUS"));
				return fahrgerat;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
