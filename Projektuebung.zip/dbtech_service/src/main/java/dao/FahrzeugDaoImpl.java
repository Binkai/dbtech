package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import object.Fahrzeug;

public class FahrzeugDaoImpl implements FahrzeugDao {
	private Connection connection;
	public void setConnection(Connection connection){
		this.connection = connection;
	}
	@Override
	public Fahrzeug getFahrzeugbyKennzeichen(String Kennzeichen) {
		// TODO Auto-generated method stub
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT * FROM FAHRZEUG WHERE KENNZEICHEN = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setString(1, Kennzeichen);
			result = preparedState.executeQuery();
			if(result.next()){
				Fahrzeug fahr = new Fahrzeug();
				fahr.setAchsen(result.getInt("Achsen"));
				fahr.setFzg_id(result.getLong("FZ_ID"));
				fahr.setSskl_id(result.getInt("SSKL_ID"));
				fahr.setKennzeichen(Kennzeichen);
				fahr.setAbmeldedatum(result.getDate("ABMELDEDATUM"));
				return fahr;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
