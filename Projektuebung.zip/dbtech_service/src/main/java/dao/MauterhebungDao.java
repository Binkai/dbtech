package dao;

import object.Mauterhebung;

public interface MauterhebungDao {

	public boolean insertMauterhebung(Mauterhebung Mauterhebung);
}
