package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import object.Mautkategorie;

public class MautkategorieDaoImpl implements MautkategorieDao {
	private Connection connection;
	public void setConnection(Connection connection){
		this.connection = connection;
	}
	@Override
	public Mautkategorie getMautkategoriebyAchsanzahlAndSSKL(int SSKL_ID, int Achsanzahl) {
		
		return null;
	}
	@Override
	public Mautkategorie getMautkategorieByID(int KATEGORIE_ID) {
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT * FROM MAUTKATEGORIE WHERE KATEGORIE_ID = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setInt(1, KATEGORIE_ID);
			result = preparedState.executeQuery();
			if(result.next()){

				Mautkategorie mautkat = new Mautkategorie();
				mautkat.setAchszahl(result.getString("Achszahl"));
				return mautkat;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
