package dao;

import object.Mautkategorie;

public interface MautkategorieDao {

	public Mautkategorie getMautkategoriebyAchsanzahlAndSSKL(int SSKL_ID, int Achsanzahl);
	public Mautkategorie getMautkategorieByID(int KATEGORIE_ID);
}
