package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import object.Mautabschnitt;

public class MautabschnittDaoImpl implements MautabschnittDao {
	private Connection connection;
	public void setConnection(Connection connection){
		this.connection = connection;
	}
	public Mautabschnitt getMautabschnittById(int abschnitts_id){
		PreparedStatement preparedState = null;
		ResultSet result = null;
		String query = "SELECT LAENGE FROM MAUTABSCHNITT WHERE ABSCHNITTS_ID = ?";
		try {
			preparedState = connection.prepareStatement(query);
			preparedState.setInt(1, abschnitts_id);
			result = preparedState.executeQuery();
			if(result.next()){
				Mautabschnitt abschnitt = new Mautabschnitt();
				abschnitt.setAbschnitts_ID(abschnitts_id);
				abschnitt.setLaenge(result.getInt("Laenge"));
				return abschnitt;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
