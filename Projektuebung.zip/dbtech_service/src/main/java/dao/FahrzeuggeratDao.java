package dao;

import object.Fahrzeuggerat;

public interface FahrzeuggeratDao {

	public Fahrzeuggerat getFahrzeuggeratbyKennzeichenAndFZID(long FZ_ID);
}
