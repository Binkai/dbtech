package object;

public class Mautabschnitt {

	private int Abschnitts_ID;
	private int Laenge;
	public int getAbschnitts_ID() {
		return Abschnitts_ID;
	}
	public void setAbschnitts_ID(int abschnitts_ID) {
		Abschnitts_ID = abschnitts_ID;
	}
	public int getLaenge() {
		return Laenge;
	}
	public void setLaenge(int laenge) {
		Laenge = laenge;
	}
}
