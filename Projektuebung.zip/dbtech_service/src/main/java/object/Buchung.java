package object;

import java.sql.Date;

public class Buchung {

	private int BUCHUNG_ID;
	private int Abschnitts_ID;
	private String Kennzeichen;
	private Date Befahrungsdatum;
	private int B_ID;
	private int Kategorie_ID;
	public int getBUCHUNG_ID() {
		return BUCHUNG_ID;
	}
	public void setBUCHUNG_ID(int bUCHUNG_ID) {
		BUCHUNG_ID = bUCHUNG_ID;
	}
	public int getAbschnitts_ID() {
		return Abschnitts_ID;
	}
	public void setAbschnitts_ID(int abschnitts_ID) {
		Abschnitts_ID = abschnitts_ID;
	}
	public String getKennzeichen() {
		return Kennzeichen;
	}
	public void setKennzeichen(String kennzeichen) {
		Kennzeichen = kennzeichen;
	}
	public Date getBefahrungsdatum() {
		return Befahrungsdatum;
	}
	public void setBefahrungsdatum(Date befahrungsdatum) {
		Befahrungsdatum = befahrungsdatum;
	}
	public int getB_ID() {
		return B_ID;
	}
	public void setB_ID(int b_ID) {
		B_ID = b_ID;
	}
	public int getKategorie_ID() {
		return Kategorie_ID;
	}
	public void setKategorie_ID(int kategorie_ID) {
		Kategorie_ID = kategorie_ID;
	}
}
