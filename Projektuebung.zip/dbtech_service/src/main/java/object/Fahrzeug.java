package object;

import java.sql.Date;

public class Fahrzeug {

	private long fzg_id;
	private int achsen;
	private String kennzeichen;
	private int sskl_id;
	private Date Abmeldedatum;
	public long getFzg_id() {
		return fzg_id;
	}
	public void setFzg_id(long fzg_id) {
		this.fzg_id = fzg_id;
	}
	public int getAchsen() {
		return achsen;
	}
	public void setAchsen(int achsen) {
		this.achsen = achsen;
	}
	public String getKennzeichen() {
		return kennzeichen;
	}
	public void setKennzeichen(String kennzeichen) {
		this.kennzeichen = kennzeichen;
	}
	public int getSskl_id() {
		return sskl_id;
	}
	public void setSskl_id(int sskl_id) {
		this.sskl_id = sskl_id;
	}
	public Date getAbmeldedatum() {
		return Abmeldedatum;
	}
	public void setAbmeldedatum(Date abmeldedatum) {
		Abmeldedatum = abmeldedatum;
	}
	
	
}
