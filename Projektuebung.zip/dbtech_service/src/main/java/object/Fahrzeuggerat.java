package object;

public class Fahrzeuggerat {

	private int FZGerat_ID;
	private int FZ_ID;
	private String status;
	public int getFZGerat_ID() {
		return FZGerat_ID;
	}
	public void setFZGerat_ID(int fZGerat_ID) {
		FZGerat_ID = fZGerat_ID;
	}
	public int getFZ_ID() {
		return FZ_ID;
	}
	public void setFZ_ID(int fZ_ID) {
		FZ_ID = fZ_ID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
