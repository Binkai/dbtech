package object;

public class Mautkategorie {

	private int Kategorie_ID;
	private String achszahl;
	private float mautsatz_je_km;
	public int getKategorie_ID() {
		return Kategorie_ID;
	}
	public void setKategorie_ID(int kategorie_ID) {
		Kategorie_ID = kategorie_ID;
	}
	public String getAchszahl() {
		return achszahl;
	}
	public void setAchszahl(String achszahl) {
		this.achszahl = achszahl;
	}
	public float getMautsatz_je_km() {
		return mautsatz_je_km;
	}
	public void setMautsatz_je_km(float mautsatz_je_km) {
		this.mautsatz_je_km = mautsatz_je_km;
	}
}
