package object;

import java.sql.Date;

public class Mauterhebung {

	private int Maut_Id;
	private int Abschnitts_Id;
	private int Fzg_ID;
	private int kategorie_id;
	private Date Befahrungsdatum;
	private float Kosten;
	public int getMaut_Id() {
		return Maut_Id;
	}
	public void setMaut_Id(int maut_Id) {
		Maut_Id = maut_Id;
	}
	public int getAbschnitts_Id() {
		return Abschnitts_Id;
	}
	public void setAbschnitts_Id(int abschnitts_Id) {
		Abschnitts_Id = abschnitts_Id;
	}
	public int getFzg_ID() {
		return Fzg_ID;
	}
	public void setFzg_ID(int fzg_ID) {
		Fzg_ID = fzg_ID;
	}
	public int getKategorie_id() {
		return kategorie_id;
	}
	public void setKategorie_id(int kategorie_id) {
		this.kategorie_id = kategorie_id;
	}
	public Date getBefahrungsdatum() {
		return Befahrungsdatum;
	}
	public void setBefahrungsdatum(Date befahrungsdatum) {
		Befahrungsdatum = befahrungsdatum;
	}
	public float getKosten() {
		return Kosten;
	}
	public void setKosten(float kosten) {
		Kosten = kosten;
	}
}
